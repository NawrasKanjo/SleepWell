class Data {
  //String? data;
  double? percent;

  Data({this.percent});
}
