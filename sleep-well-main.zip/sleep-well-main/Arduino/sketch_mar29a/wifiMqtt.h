#include "rpcWiFi.h"

const char* ssid = "SEM";
const char* password =  "sem2025gu";

